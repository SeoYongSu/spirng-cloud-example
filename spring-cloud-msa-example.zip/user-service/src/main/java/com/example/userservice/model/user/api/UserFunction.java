package com.example.userservice.model.user.api;

public class UserFunction {
}
