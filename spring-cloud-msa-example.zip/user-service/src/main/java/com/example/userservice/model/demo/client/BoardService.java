package com.example.userservice.model.demo.client;

public class BoardService {
}
